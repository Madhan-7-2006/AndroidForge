# MADWICK — Native Android AI Companion (Kotlin + Jetpack Compose)

## Build Signed Production APK
1. Generate Keystore:
   keytool -genkey -v -keystore madwick-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias madwick

2. Compile:
   ./gradlew assembleRelease

3. Align & Sign:
   zipalign -v -p 4 app-release-unsigned.apk madwick-aligned.apk
   apksigner sign --ks madwick-release.jks --out madwick-v1.0-release.apk madwick-aligned.apk

4. Install:
   adb install -r madwick-v1.0-release.apk