package com.madwick.ai.data.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class GeminiAiService(
    private val serverProxyBaseUrl: String = "https://your-server-proxy.app",
    private var customApiKey: String? = null
) {
    private val client = OkHttpClient()

    suspend fun queryMadwick(
        messages: List<Pair<String, String>>,
        relevantMemories: List<String>
    ): Result<String> = withContext(Dispatchers.IO) {
        val payload = JSONObject()
        val msgArray = JSONArray()
        messages.forEach { (role, content) ->
            msgArray.put(JSONObject().put("role", role).put("content", content))
        }
        payload.put("messages", msgArray)

        val body = payload.toString().toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url("$serverProxyBaseUrl/api/chat").post(body).build()

        try {
            val response = client.newCall(req).execute()
            val text = JSONObject(response.body?.string() ?: "{}").optString("text")
            Result.success(text)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}