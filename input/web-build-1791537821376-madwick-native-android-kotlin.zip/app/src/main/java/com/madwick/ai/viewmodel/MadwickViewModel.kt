package com.madwick.ai.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.madwick.ai.data.ai.GeminiAiService
import com.madwick.ai.data.local.MadwickDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MadwickViewModel(application: Application) : AndroidViewModel(application) {
    private val db = MadwickDatabase.getDatabase(application)
    private val memoryDao = db.memoryDao()
    private val aiService = GeminiAiService()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    fun sendMessage(userText: String, onReply: (String) -> Unit) {
        _isProcessing.value = true
        viewModelScope.launch {
            val memories = memoryDao.findRelevantMemories(userText, 3).map { it.content }
            val result = aiService.queryMadwick(listOf("user" to userText), memories)
            _isProcessing.value = false
            result.onSuccess { onReply(it) }
        }
    }
}