package com.madwick.ai.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.madwick.ai.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactor(
    isProcessing: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 200.dp,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "reactorTransition")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isProcessing) 2500 else 14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "statorRotation"
    )

    Box(modifier = modifier.size(size).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(size.toPx() / 2, size.toPx() / 2)
            val radius = size.toPx() / 2

            // Chassis
            drawCircle(Color(0xFF16161C), radius * 0.96f, center, style = Stroke(8f))
            drawCircle(MetallicGold, radius * 0.98f, center, style = Stroke(2f))

            // Stator
            rotate(degrees = rotation, pivot = center) {
                drawCircle(Color(0xFF1E1E26), radius * 0.78f, center, style = Stroke(24f))
                for (i in 0 until 10) {
                    val angle = (i * 36.0 * Math.PI / 180.0).toFloat()
                    val pos = Offset(center.x + (radius * 0.78f) * cos(angle), center.y + (radius * 0.78f) * sin(angle))
                    drawCircle(MetallicGold, 8f, pos, style = Stroke(2f))
                    drawCircle(ArcReactorBlue, 4f, pos)
                }
            }

            // Glowing Torus
            drawCircle(ArcReactorBlue, radius * 0.52f, center, style = Stroke(6f))

            // Plasma Core
            drawCircle(ArcReactorBlue.copy(alpha = 0.5f), radius * 0.28f, center)
            drawCircle(Color.White, radius * 0.12f, center)
        }
    }
}