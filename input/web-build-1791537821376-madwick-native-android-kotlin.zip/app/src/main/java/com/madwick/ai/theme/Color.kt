package com.madwick.ai.theme

import androidx.compose.ui.graphics.Color

val MainBackground = Color(0xFF0A0A0C)       // Near-black
val SecondaryBackground = Color(0xFF151519)  // Charcoal
val PrimaryArmourRed = Color(0xFFB5121B)     // Armor red
val DarkRed = Color(0xFF690B12)              // Dark red
val MetallicGold = Color(0xFFF5B82E)         // Gold / Yellow highlight
val ArcReactorBlue = Color(0xFF00CFFF)       // Bright Cyan Arc Reactor
val PrimaryText = Color(0xFFF5F5F7)          // Crisp primary text
val SecondaryText = Color(0xFFA7A7B0)        // Technical secondary text
val ErrorColor = Color(0xFFFF4545)           // Error indication