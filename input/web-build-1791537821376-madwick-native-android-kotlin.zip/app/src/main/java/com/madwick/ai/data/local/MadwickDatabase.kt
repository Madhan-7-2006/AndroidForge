package com.madwick.ai.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.madwick.ai.data.local.dao.MemoryDao
import com.madwick.ai.data.local.dao.NoteDao
import com.madwick.ai.data.local.dao.TaskDao
import com.madwick.ai.data.local.entities.MemoryEntity
import com.madwick.ai.data.local.entities.NoteEntity
import com.madwick.ai.data.local.entities.TaskEntity

@Database(
    entities = [MemoryEntity::class, NoteEntity::class, TaskEntity::class],
    version = 1,
    exportSchema = false
)
abstract class MadwickDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao
    abstract fun noteDao(): NoteDao
    abstract fun taskDao(): TaskDao

    companion object {
        @Volatile
        private var INSTANCE: MadwickDatabase? = null

        fun getDatabase(context: Context): MadwickDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    MadwickDatabase::class.java,
                    "madwick_room.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}